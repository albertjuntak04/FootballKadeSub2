package com.example.footballschedule.model

import com.example.footballschedule.Team

data class TeamResponse(
    val teams: List<Team>)