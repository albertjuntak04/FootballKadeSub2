package com.example.footballschedule.league

import com.example.footballschedule.model.MatchDetail

interface LeagueView {
    fun showList(data:League)
}