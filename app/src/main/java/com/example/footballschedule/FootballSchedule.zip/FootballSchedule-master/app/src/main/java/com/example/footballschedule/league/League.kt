package com.example.footballschedule.league

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class League(
    @SerializedName("strLeague")
    var leagueName: String? = null,

    @SerializedName("strTwitter")
    var leagueTwitter: String? = null,

    @SerializedName("strgender")
    var leagueGender: String? = null,

    @SerializedName("strCountry")
    var leagueCountry: String? = null
):Parcelable