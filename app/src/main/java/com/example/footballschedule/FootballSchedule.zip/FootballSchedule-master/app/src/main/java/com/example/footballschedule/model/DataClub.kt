package com.example.footballschedule

import android.media.Image
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DataClub(val image: Int, val name:String?, val id:Int?): Parcelable