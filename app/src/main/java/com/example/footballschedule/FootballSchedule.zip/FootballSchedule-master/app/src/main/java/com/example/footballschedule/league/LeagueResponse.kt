package com.example.footballschedule.league

class LeagueResponse(
  val leagues: List<League>
)
