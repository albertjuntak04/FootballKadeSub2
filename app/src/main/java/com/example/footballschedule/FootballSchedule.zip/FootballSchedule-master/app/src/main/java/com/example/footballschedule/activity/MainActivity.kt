package com.example.footballschedule.activity

import android.app.SearchManager
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.footballschedule.DataClub
import com.example.footballschedule.R
import com.example.footballschedule.adapter.MainAdapter
import com.example.footballschedule.activity.SearchEventActivity
import org.jetbrains.anko.startActivity

class MainActivity : AppCompatActivity() {
    var  items: MutableList<DataClub> = mutableListOf()
    companion object{
        public const val PARCELABLE_ITEM_DATA = "item data"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = findViewById<RecyclerView>(R.id.recycle_league)
        initData()
        list.adapter = MainAdapter(this, items){
            startActivity<DetailLeagueActivity>(PARCELABLE_ITEM_DATA to it)
        }
        list.layoutManager = LinearLayoutManager(this)

    }

    private fun initData(){
        val name = resources.getStringArray(R.array.league)
        val image = resources.obtainTypedArray(R.array.imageLanguange)
        val id = resources.getIntArray(R.array.id_team)
        items.clear()
        for (i in name.indices){
            items.add(
                DataClub(
                    image.getResourceId(i, 0)
                    , name[i], id[i]
                )
            )
        }
        image.recycle()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_search, menu)

        val searchView = menu?.findItem(R.id.actionSearch)?.actionView as SearchView?
            searchView?.queryHint = "Search Matches"
            searchView?.setOnQueryTextListener(object  : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(p0: String?): Boolean {
                    startActivity<SearchEventActivity>("query" to p0)
                    return false
                }

                override fun onQueryTextChange(p0: String?): Boolean {
                    return false

                }

            })

        return true
    }
}
