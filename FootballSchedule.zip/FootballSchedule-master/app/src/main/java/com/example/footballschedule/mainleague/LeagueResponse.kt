package com.example.footballschedule.mainleague

import com.example.footballschedule.league.League

data class LeagueResponse(
    val countrys: List<League>)

